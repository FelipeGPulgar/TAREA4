<?php
// Habilitar la visualización de errores
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Incluir la conexión a la base de datos
include $_SERVER['DOCUMENT_ROOT'] . '/Restaurant_Siglo_XXI/login/conexion.php';

$message = "";

// Procesar el formulario de inicio de sesión
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Comprobación temporal para verificar el correo ingresado
    echo "<script>console.log('Correo ingresado: " . htmlspecialchars($username) . "');</script>";

    // Prepara y ejecuta la consulta
    $stmt = $conn->prepare("SELECT id_usuario, password, rol FROM usuarios WHERE email = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->store_result();

    // Verifica si se encontró el correo en la base de datos
    if ($stmt->num_rows > 0) {
        $stmt->bind_result($user_id, $hashed_password, $role);
        $stmt->fetch();

        // Mostrar las contraseñas para verificar
        echo "<script>console.log('Contraseña ingresada: " . htmlspecialchars($password) . "');</script>";
        echo "<script>console.log('Hash almacenado: " . htmlspecialchars($hashed_password) . "');</script>";

        // Verifica la contraseña
        if (password_verify($password, $hashed_password)) {
            // Iniciar sesión y almacenar información en la sesión
            session_start();
            $_SESSION['user_email'] = $username;
            $_SESSION['user_id'] = $user_id;
            $_SESSION['user_role'] = $role;

            // Redirigir según el rol
            switch ($role) {
                case 'Administrador':
                    header("Location: /Restaurant_Siglo_XXI/panel_admin/admin/administracion.php");
                    exit();
                case 'Bodega':
                    header("Location: /Restaurant_Siglo_XXI/cuentas/bodegavista/bodegavista.php");
                    exit();
                case 'Finanzas':
                    header("Location: /Restaurant_Siglo_XXI/cuentas/finanza/finanzasvista.php");
                    exit();
                case 'Cocina':
                    header("Location: /Restaurant_Siglo_XXI/cuentas/cocina/cocinavista.php");
                    exit();
                case 'Cliente':
                    header("Location: /Restaurant_Siglo_XXI/cliente/clientelayout/cliente.php");
                    exit();
                default:
                    $message = "Rol no reconocido.";
                    break;
            }
        } else {
            $message = "Contraseña incorrecta.";
        }
    } else {
        $message = "No se encontró un usuario con ese correo.";
    }

    $stmt->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar Sesión - Restaurante Siglo XXI</title>
    <link rel="stylesheet" href="login.css">
</head>
<body>

    <div class="main-form">
        <img class="logo" src="http://localhost/Restaurant_Siglo_XXI/iconos/restaurant-outline.svg" alt="Logo Restaurante Siglo XXI">
        <!-- Mostrar mensajes de error o éxito -->
        <?php if ($message): ?>
            <div class="message"><?php echo htmlspecialchars($message); ?></div>
        <?php endif; ?>
        
        <!-- Formulario para login -->
        <form action="" method="POST">
            <input type="text" name="username" placeholder="Email" required>
            <input type="password" name="password" placeholder="Contraseña" required>
            <input type="submit" value="Iniciar sesión">
        </form>
        
    </div>
    
</body>
</html>
