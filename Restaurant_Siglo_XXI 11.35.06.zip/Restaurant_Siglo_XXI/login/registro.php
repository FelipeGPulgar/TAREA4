<?php
// Habilitar la visualización de errores
error_reporting(E_ALL);
ini_set('display_errors', 1);

include $_SERVER['DOCUMENT_ROOT'] . '/Restaurant_Siglo_XXI/login/conexion.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recoger datos del formulario
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Verificar si el correo ya existe
    $query = "SELECT email FROM usuarios WHERE email = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows == 0) { // Si no existe el correo
        // Hashear la contraseña antes de insertarla
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // Insertar nuevo usuario
        $query = "INSERT INTO usuarios (nombre, email, password, rol) VALUES (?, ?, ?, 'Cliente')";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("sss", $username, $email, $hashed_password); // Insertar con hash

        if ($stmt->execute()) {
            // Redirigir a login después de un registro exitoso
            header("Location: login.php?registro=exitoso");
            exit();
        } else {
            echo "Error en el registro: " . $conn->error; // Mensaje de error detallado
        }
    } else {
        echo "El correo ya está registrado.";
    }

    $stmt->close();
}

$conn->close();
?>
