<?php
$host = "localhost";
$user = "root";
$password = "";
$dbname = "restaurante_siglo_XXI"; // El nombre de la base de datos

$conn = new mysqli($host, $user, $password, $dbname);

if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}
?>
