<?php
// Habilitar la visualización de errores
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Incluir la conexión a la base de datos
include $_SERVER['DOCUMENT_ROOT'] . '/Restaurant_Siglo_XXI/login/conexion.php';

// Verificar si el usuario está autenticado
session_start();
if (!isset($_SESSION['user_email'])) {
    header("Location: login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Procesar el formulario
    $nombre = $_POST['nombre'];
    $email = $_POST['email'];
    $rol = $_POST['rol'];
    $password = $_POST['password'];

    // Hashear la contraseña
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // Insertar nuevo usuario en la base de datos
    $query = "INSERT INTO usuarios (nombre, email, password, rol) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ssss", $nombre, $email, $hashed_password, $rol);

    if ($stmt->execute()) {
        header("Location: administracion.php?message=Usuario agregado con éxito");
        exit();
    } else {
        echo "Error al agregar el usuario: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agregar Usuario - Restaurante Siglo XXI</title>
    <link rel="stylesheet" href="administracion.css">
</head>
<body>
    <h1>Agregar Nuevo Usuario</h1>
    <form method="POST">
        <label for="nombre">Nombre:</label>
        <input type="text" name="nombre" required>

        <label for="email">Email:</label>
        <input type="email" name="email" required>

        <label for="rol">Rol:</label>
        <select name="rol" required>
            <option value="Administrador">Administrador</option>
            <option value="Bodega">Bodega</option>
            <option value="Finanzas">Finanzas</option>
            <option value="Cocina">Cocina</option>
            <option value="Cliente">Cliente</option>
        </select>

        <label for="password">Contraseña:</label>
        <input type="password" name="password" required>

        <button type="submit">Agregar Usuario</button>
    </form>
    <a href="administracion.php">Volver al Panel</a>
</body>
</html>
