<?php
// Habilitar la visualización de errores
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Incluir la conexión a la base de datos
include $_SERVER['DOCUMENT_ROOT'] . '/Restaurant_Siglo_XXI/login/conexion.php';

// Verificar si el usuario está autenticado
session_start();
if (!isset($_SESSION['user_email'])) {
    header("Location: login.php");
    exit();
}

// Obtener el ID del usuario
if (!isset($_GET['id'])) {
    header("Location: administracion.php");
    exit();
}

$id_usuario = $_GET['id'];
$query = "SELECT * FROM usuarios WHERE id_usuario = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $id_usuario);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    header("Location: administracion.php");
    exit();
}

$user = $result->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Procesar el formulario
    $nombre = $_POST['nombre'];
    $email = $_POST['email'];
    $rol = trim($_POST['rol']);  // Sanitiza el rol
    $new_password = $_POST['new_password'];

    // Verifica que el rol sea válido
    $valid_roles = ['Administrador', 'Cliente', 'Bodega', 'Finanzas', 'Cocina'];
    if (!in_array($rol, $valid_roles)) {
        die("Error: Rol no válido. Rol proporcionado: " . $rol);
    }

    // Actualizar el usuario
    $update_query = "UPDATE usuarios SET nombre = ?, email = ?, rol = ?";

    if (!empty($new_password)) {
        // Solo actualizar la contraseña si se ha ingresado una nueva
        $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
        $update_query .= ", password = ? WHERE id_usuario = ?";
        $stmt = $conn->prepare($update_query);
        
        // Imprimir valores para depuración
        var_dump($nombre, $email, $rol, $hashed_password, $id_usuario);

        if (!$stmt->bind_param("ssssi", $nombre, $email, $rol, $hashed_password, $id_usuario)) {
            die("Error al vincular parámetros: " . $stmt->error);
        }
    } else {
        // Actualizar sin cambiar la contraseña
        $update_query .= " WHERE id_usuario = ?";
        $stmt = $conn->prepare($update_query);
        
        // Imprimir valores para depuración
        var_dump($nombre, $email, $rol, $id_usuario);

        if (!$stmt->bind_param("sssi", $nombre, $email, $rol, $id_usuario)) {
            die("Error al vincular parámetros: " . $stmt->error);
        }
    }

    // Ejecutar la consulta y manejar el resultado
    if ($stmt->execute()) {
        header("Location: administracion.php?message=Usuario actualizado con éxito");
        exit();
    } else {
        echo "Error al actualizar el usuario: " . $stmt->error; // Cambié $conn->error por $stmt->error
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Usuario - Restaurante Siglo XXI</title>
    <link rel="stylesheet" href="administracion.css">
</head>
<body>
    <h1>Editar Usuario</h1>
    <form method="POST">
        <label for="nombre">Nombre:</label>
        <input type="text" name="nombre" value="<?php echo htmlspecialchars($user['nombre']); ?>" required>
        
        <label for="email">Email:</label>
        <input type="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" required>
        
        <label for="rol">Rol:</label>
        <select name="rol" required>
            <option value="Administrador" <?php echo $user['rol'] === 'Administrador' ? 'selected' : ''; ?>>Administrador</option>
            <option value="Bodega" <?php echo $user['rol'] === 'Bodega' ? 'selected' : ''; ?>>Bodega</option>
            <option value="Finanzas" <?php echo $user['rol'] === 'Finanzas' ? 'selected' : ''; ?>>Finanzas</option>
            <option value="Cocina" <?php echo $user['rol'] === 'Cocina' ? 'selected' : ''; ?>>Cocina</option>
            <option value="Cliente" <?php echo $user['rol'] === 'Cliente' ? 'selected' : ''; ?>>Cliente</option>
        </select>
        
        <label for="new_password">Nueva Contraseña (dejar en blanco si no se quiere cambiar):</label>
        <input type="password" name="new_password">

        <button type="submit">Actualizar Usuario</button>
    </form>
    <a href="administracion.php">Volver al Panel</a>
</body>
</html>
