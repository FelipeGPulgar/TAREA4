<?php
// Habilitar la visualización de errores
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Incluir la conexión a la base de datos
include $_SERVER['DOCUMENT_ROOT'] . '/Restaurant_Siglo_XXI/login/conexion.php';

// Verificar si el usuario está autenticado
session_start();
if (!isset($_SESSION['user_email'])) {
    header("Location: login.php");
    exit();
}

if (isset($_GET['id'])) {
    $id_usuario = $_GET['id'];

    // Eliminar el usuario
    $query = "DELETE FROM usuarios WHERE id_usuario = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $id_usuario);

    if ($stmt->execute()) {
        header("Location: administracion.php?message=Usuario eliminado con éxito");
        exit();
    } else {
        echo "Error al eliminar el usuario: " . $conn->error;
    }
} else {
    header("Location: administracion.php");
    exit();
}
?>
