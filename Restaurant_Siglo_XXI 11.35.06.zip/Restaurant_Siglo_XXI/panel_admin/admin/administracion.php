<?php
// Habilitar la visualización de errores
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Incluir la conexión a la base de datos
include $_SERVER['DOCUMENT_ROOT'] . '/Restaurant_Siglo_XXI/login/conexion.php';

// Verificar si el usuario está autenticado
session_start();
if (!isset($_SESSION['user_email'])) {
    header("Location: login.php");
    exit();
}

// Obtener información del usuario autenticado
$email = $_SESSION['user_email'];

// Mostrar mensaje de acción si existe
$message = "";
if (isset($_GET['message'])) {
    $message = htmlspecialchars($_GET['message']);
}

// Consulta para obtener los usuarios
$query = "SELECT id_usuario, nombre, email, rol FROM usuarios";
$result = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Administración - Restaurante Siglo XXI</title>
    <link rel="stylesheet" href="administracion.css"> <!-- Cambia el nombre del archivo según tu diseño -->
    <style>
        /* Estilos CSS para mensajes */
        .message {
            background-color: #e7f3fe;
            color: #31708f;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #bce8f1;
            border-radius: 5px;
        }
    </style>
</head>
<body>
    <header>
        <h1>Panel de Administración</h1>
        <nav>
            <ul>
                <li><a href="http://localhost/Restaurant_Siglo_XXI/panel_admin/bodega/bodega.php">Bodega</a></li>
                <li><a href="http://localhost/Restaurant_Siglo_XXI/panel_admin/finanza/finanzas.php">Finanzas</a></li>
                <li><a href="http://localhost/Restaurant_Siglo_XXI/panel_admin/cocina/cocina.php">Cocina</a></li>
                <li><a href="http://localhost/Restaurant_Siglo_XXI/login/login.php">Cerrar sesión</a></li>
            </ul>
        </nav>
    </header>
    
    <main>
        <h2>Bienvenido, <?php echo htmlspecialchars($email); ?></h2>

        <?php if ($message): ?>
            <div class="message"><?php echo $message; ?></div>
        <?php endif; ?>

        <section>
            <h3>Gestión de Usuarios</h3>
            <a href="agregar_usuario.php">Agregar Nuevo Usuario</a>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nombre</th>
                        <th>Email</th>
                        <th>Rol</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if ($result) {
                        if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                echo "<tr>
                                        <td>{$row['id_usuario']}</td>
                                        <td>{$row['nombre']}</td>
                                        <td>{$row['email']}</td>
                                        <td>{$row['rol']}</td>
                                        <td>
                                            <a href='editar_usuario.php?id={$row['id_usuario']}'>Editar</a>
                                            <a href='eliminar_usuario.php?id={$row['id_usuario']}' onclick=\"return confirm('¿Estás seguro de que deseas eliminar este usuario?');\">Eliminar</a>
                                        </td>
                                      </tr>";
                            }
                        } else {
                            echo "<tr><td colspan='5'>No hay usuarios registrados.</td></tr>";
                        }
                    } else {
                        echo "<tr><td colspan='5'>Error al obtener usuarios: " . htmlspecialchars($conn->error) . "</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </section>
    </main>
</body>
</html>
