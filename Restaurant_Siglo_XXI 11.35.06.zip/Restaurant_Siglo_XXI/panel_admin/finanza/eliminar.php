<?php
include $_SERVER['DOCUMENT_ROOT'] . '/Restaurant_Siglo_XXI/login/conexion.php';

if (isset($_GET['id'])) {
    // Obtener y sanitizar el ID
    $id = intval($_GET['id']);

    // Preparar la consulta para eliminar de forma segura
    $stmt = $conn->prepare("DELETE FROM finanzas WHERE id_transaccion = ?");
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        header("Location: finanzas.php?mensaje=Registro eliminado con éxito");
        exit();
    } else {
        echo "<div class='mensaje' style='color: red;'>Error al eliminar registro: " . $stmt->error . "</div>";
    }

    $stmt->close();
} else {
    echo "<div class='mensaje' style='color: red;'>No se ha proporcionado un ID válido.</div>";
}

// Cerrar la conexión a la base de datos
$conn->close();
?>
