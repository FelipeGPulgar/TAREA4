<?php
// Mostrar todos los errores
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Incluir la conexión a la base de datos
include $_SERVER['DOCUMENT_ROOT'] . '/Restaurant_Siglo_XXI/login/conexion.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id_pedido = $_POST['id_pedido'];
    $accion = $_POST['accion'];

    if ($accion == 'Listo') {
        // Primero, actualiza el estado del pedido
        $query = "UPDATE pedidos SET estado = 'Listo' WHERE id_pedido = ?";
        $stmt = mysqli_prepare($conn, $query);
        mysqli_stmt_bind_param($stmt, 'i', $id_pedido);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

        // Ahora, obtenemos el monto y el nombre del producto para registrar el ingreso
        $query_pedido = "SELECT p.nombre AS nombre_producto, pe.total 
                         FROM pedidos pe
                         JOIN productos p ON pe.id_producto = p.id_producto 
                         WHERE pe.id_pedido = ?";
        $stmt_pedido = mysqli_prepare($conn, $query_pedido);
        mysqli_stmt_bind_param($stmt_pedido, 'i', $id_pedido);
        mysqli_stmt_execute($stmt_pedido);
        $resultado_pedido = mysqli_stmt_get_result($stmt_pedido);

        if ($row_pedido = mysqli_fetch_assoc($resultado_pedido)) {
            $monto = $row_pedido['total'];
            $producto = $row_pedido['nombre_producto'];

            // Inserción en finanzas
            $sql_finanzas = "INSERT INTO finanzas (tipo, monto, descripcion, razon) VALUES ('Ingreso', ?, 'Ingreso por venta de $producto', 'Plato Listo')";
            $stmt_finanzas = mysqli_prepare($conn, $sql_finanzas);
            mysqli_stmt_bind_param($stmt_finanzas, 'd', $monto);
            mysqli_stmt_execute($stmt_finanzas);
            mysqli_stmt_close($stmt_finanzas);
        }

        mysqli_stmt_close($stmt_pedido);
    }
}

// Redirigir de nuevo a cocina.php después de actualizar
header("Location: cocina.php?mensaje=Pedido marcado como listo y ingreso registrado.");
exit();
?>
