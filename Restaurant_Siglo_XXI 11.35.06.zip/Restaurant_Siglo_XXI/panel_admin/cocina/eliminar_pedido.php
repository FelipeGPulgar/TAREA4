<?php
include $_SERVER['DOCUMENT_ROOT'] . '/Restaurant_Siglo_XXI/login/conexion.php';

if (isset($_POST['id_pedido'])) { // Cambiado a $_POST
    $id_pedido = $_POST['id_pedido']; // Cambiado a $_POST

    $query = "DELETE FROM pedidos WHERE id_pedido = ?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, 'i', $id_pedido);
    mysqli_stmt_execute($stmt);

    if (mysqli_stmt_affected_rows($stmt) > 0) {
        echo "Pedido eliminado con éxito.";
    } else {
        echo "No se pudo eliminar el pedido o el pedido no existe.";
    }

    mysqli_stmt_close($stmt);
    header("Location: cocina.php"); // Redirigir a la página principal después de eliminar
    exit();
} else {
    echo "ID de pedido no especificado.";
}

mysqli_close($conn);
?>
<a href="cocina.php">Volver</a>
