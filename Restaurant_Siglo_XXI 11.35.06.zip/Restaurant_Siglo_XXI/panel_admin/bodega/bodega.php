<?php
// Conexión a la base de datos
include $_SERVER['DOCUMENT_ROOT'] . '/Restaurant_Siglo_XXI/login/conexion.php';

// Manejar la inserción de un nuevo producto
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['accion']) && $_POST['accion'] == 'agregar') {
    $nombre = $_POST['nombre'];
    $descripcion = $_POST['descripcion'];
    $precio = $_POST['precio'];
    $stock = $_POST['stock'];
    $categoria = $_POST['categoria'];

    $imagen = $_FILES['imagen']['name'];
    $ruta_imagen = $_SERVER['DOCUMENT_ROOT'] . '/Restaurant_Siglo_XXI/imagenes/' . $imagen;
    $url_imagen = 'imagenes/' . $imagen;
    $uploadOk = 1;

    $check = getimagesize($_FILES['imagen']['tmp_name']);
    if ($check === false) {
        $uploadOk = 0;
        echo "<div class='mensaje'>El archivo no es una imagen.</div>";
    }

    if ($uploadOk && move_uploaded_file($_FILES['imagen']['tmp_name'], $ruta_imagen)) {
        $sql = "INSERT INTO productos (nombre, descripcion, precio, stock, categoria, imagen) 
                VALUES ('$nombre', '$descripcion', '$precio', '$stock', '$categoria', '$url_imagen')";

        if ($conn->query($sql) === TRUE) {
            header("Location: bodega.php?mensaje=Producto agregado con éxito");
            exit();
        } else {
            echo "<div class='mensaje'>Error al agregar producto: " . $conn->error . "</div>";
        }
    }
}

// Manejar la edición de un producto
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['accion']) && $_POST['accion'] == 'editar') {
    $id_producto = $_POST['id_producto'];
    $nombre = $_POST['nombre'];
    $descripcion = $_POST['descripcion'];
    $precio = $_POST['precio'];
    $stock = $_POST['stock'];
    $categoria = $_POST['categoria'];

    $imagen = $_FILES['imagen']['name'];
    $ruta_imagen = $_SERVER['DOCUMENT_ROOT'] . '/Restaurant_Siglo_XXI/imagenes/' . $imagen;
    $url_imagen = 'imagenes/' . $imagen;

    if ($imagen && move_uploaded_file($_FILES['imagen']['tmp_name'], $ruta_imagen)) {
        $sql = "UPDATE productos SET nombre='$nombre', descripcion='$descripcion', precio='$precio', stock='$stock', categoria='$categoria', imagen='$url_imagen' WHERE id_producto='$id_producto'";
    } else {
        $sql = "UPDATE productos SET nombre='$nombre', descripcion='$descripcion', precio='$precio', stock='$stock', categoria='$categoria' WHERE id_producto='$id_producto'";
    }

    if ($conn->query($sql) === TRUE) {
        header("Location: bodega.php?mensaje=Producto Actualizado con éxito");
        exit();
    } else {
        echo "<div class='mensaje'>Error al actualizar el producto: " . $conn->error . "</div>";
    }
}

// Manejar la eliminación de un producto
if (isset($_GET['id_eliminar'])) {
    $id_producto = $_GET['id_eliminar'];
    $query = "SELECT imagen FROM productos WHERE id_producto='$id_producto'";
    $result = $conn->query($query);

    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $imagen_a_eliminar = $_SERVER['DOCUMENT_ROOT'] . '/Restaurant_Siglo_XXI/' . $row['imagen'];

        if (file_exists($imagen_a_eliminar)) {
            unlink($imagen_a_eliminar);
        }

        $sql = "DELETE FROM productos WHERE id_producto='$id_producto'";
        if ($conn->query($sql) === TRUE) {
            header("Location: bodega.php?mensaje=Producto eliminado con éxito");
            exit();
        } else {
            echo "<div class='mensaje'>Error al eliminar producto: " . $conn->error . "</div>";
        }
    }
}

// Obtener todos los productos
$query = "SELECT * FROM productos";
$result = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Bodega</title>
    <link rel="stylesheet" href="bodega.css">
</head>
<body>
    <h1>Gestión de Bodega</h1>
    
    <?php if (isset($_GET['mensaje'])): ?>
        <div class="mensaje" style="color: green;">
            <?php echo htmlspecialchars($_GET['mensaje']); ?>
        </div>
    <?php endif; ?>

    <!-- Botón de volver al inicio -->
    <a class="btn-volver" href="/Restaurant_Siglo_XXI/panel_admin/admin/administracion.php">Volver al Inicio</a>

    <!-- Formulario para agregar un nuevo producto -->
    <div class="nuevo-producto">
        <h2>Añadir Nuevo Producto</h2>
        <form action="" method="POST" enctype="multipart/form-data">
            <input type="hidden" name="accion" value="agregar">
            <label for="nombre">Nombre del Producto</label>
            <input type="text" name="nombre" id="nombre" required>
            <label for="descripcion">Descripción</label>
            <textarea name="descripcion" id="descripcion" required></textarea>
            <label for="precio">Precio</label>
            <input type="number" name="precio" id="precio" required>
            <label for="stock">Stock</label>
            <input type="number" name="stock" id="stock" required>
            <label for="categoria">Categoría</label>
            <input type="text" name="categoria" id="categoria" required>
            <label for="imagen">Imagen</label>
            <input type="file" name="imagen" id="imagen" accept="image/*">
            <button type="submit">Añadir Producto</button>
        </form>
    </div>

    <!-- Listado de productos existentes con opciones de editar y eliminar -->
    <!-- Listado de productos existentes con opciones de editar y eliminar -->
<h2>Productos en Bodega</h2>
<div class="grid-productos">
    <?php while ($row = $result->fetch_assoc()) { ?>
        <div class="producto">
            <form action="" method="POST" enctype="multipart/form-data">
                <input type="hidden" name="accion" value="editar">
                <input type="hidden" name="id_producto" value="<?php echo $row['id_producto']; ?>">
                <label for="descripcion_<?php echo $row['id_producto']; ?>">Nombre Del Producto</label>
                <h3><input type="text" name="nombre" value="<?php echo htmlspecialchars($row['nombre']); ?>" required></h3>
                <label for="descripcion_<?php echo $row['id_producto']; ?>">Descripción</label>
                <textarea name="descripcion" id="descripcion_<?php echo $row['id_producto']; ?>"><?php echo htmlspecialchars($row['descripcion']); ?></textarea>
                <label for="precio_<?php echo $row['id_producto']; ?>">Precio</label>
                <input type="number" name="precio" id="precio_<?php echo $row['id_producto']; ?>" value="<?php echo number_format($row['precio'], 0, '', '.'); ?>" required>
                <label for="stock_<?php echo $row['id_producto']; ?>">Stock</label>
                <input type="number" name="stock" id="stock_<?php echo $row['id_producto']; ?>" value="<?php echo $row['stock']; ?>" required>
                <label for="categoria_<?php echo $row['id_producto']; ?>">Categoría</label>
                <input type="text" name="categoria" id="categoria_<?php echo $row['id_producto']; ?>" value="<?php echo htmlspecialchars($row['categoria']); ?>" required>
                <div class="imagen-producto">
                    <?php if ($row['imagen']): ?>
                        <img src="/Restaurant_Siglo_XXI/<?php echo htmlspecialchars($row['imagen']); ?>" alt="<?php echo htmlspecialchars($row['nombre']); ?>">
                    <?php endif; ?>
                    <label class="file-label">
                        <input type="file" name="imagen" accept="image/*" onchange="showFileName(this)">
                        <span class="file-name"><?php echo $row['imagen'] ? htmlspecialchars(basename($row['imagen'])) : 'Seleccionar imagen'; ?></span>
                    </label>
                </div>

                <script>
                    function showFileName(input) {
                        const fileName = input.files[0] ? input.files[0].name : 'Seleccionar imagen';
                        input.nextElementSibling.textContent = fileName;
                    }
                </script>

                <style>
                    /* Oculta el campo de archivo, reemplazándolo con un diseño personalizado */
                    .file-label {
                        display: flex;
                        align-items: center;
                        cursor: pointer;
                    }
                    
                    .file-label input[type="file"] {
                        display: none; /* Oculta el input real */
                    }
                    
                    .file-name {
                        color: #555;
                        font-size: 1rem;
                        background-color: #f0f0f0;
                        padding: 5px 10px;
                        border-radius: 5px;
                    }
                </style>

                    <button class="btn-actualizar" type="submit">Actualizar Producto</button>
                </form>
                <a class="btn-eliminar" href="bodega.php?id_eliminar=<?php echo $row['id_producto']; ?>" onclick="return confirm('¿Estás seguro de eliminar este producto?');">Eliminar</a>
            </div>
        <?php } ?>
    </div>

</body>
</html>