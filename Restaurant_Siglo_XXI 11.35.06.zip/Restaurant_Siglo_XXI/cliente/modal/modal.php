<!-- Modal para ingresar mesa -->
<div id="modal" class="modal">
    <div class="modal-content">
        <span onclick="cerrarModal()" style="cursor:pointer;">&times;</span>
        <h2>Ingresa el número de mesa</h2>
        <form id="pedidoForm" action="cliente.php" method="post">
            <input type="number" name="id_mesa" id="id_mesa" placeholder="Número de Mesa" required>
            <input type="hidden" name="id_producto" id="id_producto">
            <input type="hidden" name="precio" id="precio">
            <button type="button" onclick="confirmarPedido()">Aceptar</button>
            <button type="button" onclick="cerrarModal()">Volver Atrás</button>
        </form>
    </div>
</div>
