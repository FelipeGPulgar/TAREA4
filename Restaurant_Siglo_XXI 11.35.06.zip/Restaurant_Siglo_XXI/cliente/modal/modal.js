document.addEventListener('DOMContentLoaded', function () {
    function mostrarModal(id_producto, precio) {
        document.getElementById('id_producto').value = id_producto;
        document.getElementById('precio').value = precio;
        document.getElementById('modal').style.display = 'flex'; // Mostrar modal
    }

    function cerrarModal() {
        document.getElementById('modal').style.display = 'none'; // Ocultar modal
    }

    function confirmarPedido() {
        document.getElementById('pedidoForm').submit(); // Enviar formulario
    }

    // Exponer funciones al ámbito global
    window.mostrarModal = mostrarModal;
    window.cerrarModal = cerrarModal;
    window.confirmarPedido = confirmarPedido;
});
