<?php
// Habilitar la visualización de errores
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();

// Incluir la conexión a la base de datos
include $_SERVER['DOCUMENT_ROOT'] . '/Restaurant_Siglo_XXI/login/conexion.php'; // Asegúrate de que esta es la ruta correcta

// Verificar si el usuario está logueado
if (!isset($_SESSION['user_id'])) {
    header('Location: /Restaurant_Siglo_XXI/login/login.php'); // Redirigir si no está logueado
    exit();
}

$id_cliente = $_SESSION['user_id']; // Asegúrate de que este ID sea correcto

// Obtener pedidos del cliente
$query = "SELECT p.id_pedido, p.fecha_hora, p.estado, pr.nombre, pr.precio 
          FROM pedidos p 
          JOIN productos pr ON p.id_producto = pr.id_producto 
          WHERE p.id_cliente = ?";
$stmt = $conn->prepare($query); // Cambiado a $conn
if (!$stmt) {
    die("Error en la preparación de la consulta: " . $conn->error);
}

$stmt->bind_param("i", $id_cliente);
$stmt->execute();
$result = $stmt->get_result();
$pedidos = $result->fetch_all(MYSQLI_ASSOC);

// Calcular el total
$total = 0;
foreach ($pedidos as $pedido) {
    $total += $pedido['precio'];
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mis Pedidos - Restaurante Siglo XXI</title>
    <link rel="stylesheet" href="/Restaurant_Siglo_XXI/cliente/pedidos/mis_pedidos.css">
</head>
<body>
    <header>
        <h1>Mis Pedidos</h1>
        <nav>
            <ul>
                <li><a href="/Restaurant_Siglo_XXI/cliente/clientelayout/cliente.php">Menú</a></li>
                <li><a href="/Restaurant_Siglo_XXI/cliente/pedidos/mis_pedidos.php">Mis Pedidos</a></li>
                <li><a href="/Restaurant_Siglo_XXI/login/login.php">Cerrar sesión</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <h2>Pedidos Realizados</h2>
        <table>
            <thead>
                <tr>
                    <th>ID Pedido</th>
                    <th>Plato</th>
                    <th>Precio</th>
                    <th>Estado</th>
                    <th>Fecha</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($pedidos)): ?>
                    <tr>
                        <td colspan="5">No has realizado pedidos.</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($pedidos as $pedido): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($pedido['id_pedido']); ?></td>
                            <td><?php echo htmlspecialchars($pedido['nombre']); ?></td>
                            <td>$<?php echo number_format($pedido['precio'], 0, ',', '.'); ?></td>
                            <td><?php echo htmlspecialchars($pedido['estado']); ?></td>
                            <td><?php echo htmlspecialchars(date('d/m/Y H:i', strtotime($pedido['fecha_hora']))); ?></td>
                        </tr>
                    <?php endforeach; ?>
                    <tr>
                        <td colspan="2" style="text-align: right;"><strong>Total:</strong></td>
                        <td><strong>$<?php echo number_format($total, 0, ',', '.'); ?></strong></td>
                        <td colspan="2"></td> <!-- Celdas vacías para alineación -->
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </main>

    <footer>
        <p>&copy; 2024 Restaurante Siglo XXI. Todos los derechos reservados.</p>
    </footer>
</body>
</html>
