<?php
// Conexión a la base de datos
$host = "localhost";
$dbname = "restaurante_siglo_XXI";
$username = "root";
$password = ""; 

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Error de conexión: " . $e->getMessage());
}

// Manejo del pedido
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['id_mesa'])) {
    $id_producto = $_POST['id_producto'];
    $precio = $_POST['precio'];
    $id_mesa = $_POST['id_mesa'];
    
    // Obtener el ID del cliente desde la sesión
    session_start();
    if (!isset($_SESSION['user_id'])) {
        header('Location: /Restaurant_Siglo_XXI/login/login.php'); // Redirigir si no está logueado
        exit();
    }
    $id_cliente = $_SESSION['user_id']; // Asegúrate de que este ID sea correcto

    // Comprobación de stock
    try {
        $stmt = $pdo->prepare("SELECT stock FROM productos WHERE id_producto = :id_producto");
        $stmt->execute(['id_producto' => $id_producto]);
        $resultado = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($resultado) {
            $stock = $resultado['stock'];

            // Verifica el stock y realiza el pedido
            if ($stock > 0) {
                // Actualiza el stock
                $nuevo_stock = $stock - 1; // Suponiendo que se añade una unidad
                $updateStmt = $pdo->prepare("UPDATE productos SET stock = :nuevo_stock WHERE id_producto = :id_producto");
                $updateStmt->execute(['nuevo_stock' => $nuevo_stock, 'id_producto' => $id_producto]);

                // Inserta el pedido
                $insertStmt = $pdo->prepare("INSERT INTO pedidos (id_mesa, id_cliente, id_producto, total, estado) VALUES (:id_mesa, :id_cliente, :id_producto, :total, 'En Preparación')");
                $total = $precio; // Ajusta según la lógica de cálculo
                $insertStmt->execute(['id_mesa' => $id_mesa, 'id_cliente' => $id_cliente, 'id_producto' => $id_producto, 'total' => $total]);

                // Redirigir con mensaje de éxito
                header("Location: cliente.php?mensaje=exito"); // Redirige a la misma página con un mensaje
                exit();
            } else {
                $mensaje = "Stock insuficiente.";
            }
        } else {
            $mensaje = "Producto no encontrado.";
        }
    } catch (Exception $e) {
        $mensaje = "Error en la consulta: " . $e->getMessage();
    }
}

// Consulta para obtener productos disponibles
$query = "SELECT * FROM productos WHERE stock > 0";
$stmt = $pdo->query($query);
$productos = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menú del Cliente - Restaurante Siglo XXI</title>
    <link rel="stylesheet" href="http://localhost/Restaurant_Siglo_XXI/cliente/clientelayout/cliente.css">
    <link rel="stylesheet" href="http://localhost/Restaurant_Siglo_XXI/cliente/modal/modal.css"> <!-- Agregar el CSS del modal -->
</head>
<body>
    <header>
        <h1>Bienvenido al Restaurante Siglo XXI</h1>
        <nav>
            <ul>
                <li><a href="cliente.php">Menú</a></li>
                <li><a href="http://localhost/Restaurant_Siglo_XXI/cliente/pedidos/mis_pedidos.php">Mis Pedidos</a></li>
                <li><a href="http://localhost/Restaurant_Siglo_XXI/login/login.php">Cerrar sesión</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <h2>Menú Disponible</h2>

        <!-- Mostrar mensaje de confirmación y recomendación después de 2 minutos -->
        <?php if (isset($_GET['mensaje'])): ?>
            <script>
                alert("<?php echo addslashes($_GET['mensaje'] === 'exito' ? 'Plato añadido exitosamente. Revise sus pedidos en Mis Pedidos.' : 'Error al procesar el pedido.'); ?>");
            </script>
        <?php endif; ?>

        <div class="menu">
            <?php if (empty($productos)): ?>
                <p>No hay productos disponibles en este momento.</p>
            <?php else: ?>
                <?php foreach ($productos as $producto): ?>
                    <div class="producto">
                        <?php $imgSrc = '/Restaurant_Siglo_XXI/' . htmlspecialchars($producto['imagen']); ?>
                        <?php if (file_exists($_SERVER['DOCUMENT_ROOT'] . $imgSrc)): ?>
                            <img src="<?php echo $imgSrc; ?>" alt="<?php echo htmlspecialchars($producto['nombre']); ?>">
                        <?php else: ?>
                            <p>Imagen no disponible</p>
                        <?php endif; ?>
                        <h3><?php echo htmlspecialchars($producto['nombre']); ?></h3>
                        <p><?php echo htmlspecialchars($producto['descripcion']); ?></p>
                        <p class="precio">Precio: $<?php echo number_format($producto['precio'], 0, ',', '.'); ?></p>
                        <p class="stock">Disponibilidad: <?php echo $producto['stock']; ?> unidades</p>
                        <button onclick="mostrarModal(<?php echo $producto['id_producto']; ?>, <?php echo $producto['precio']; ?>)">Agregar al Pedido</button>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>

        <?php include $_SERVER['DOCUMENT_ROOT'] . '/Restaurant_Siglo_XXI/cliente/modal/modal.php'; // Incluir el modal ?>

    </main>

    <footer>
        <p>&copy; 2024 Restaurante Siglo XXI. Todos los derechos reservados.</p>
    </footer>

    <!-- Cargar JavaScript al final -->
    <script src="http://localhost/Restaurant_Siglo_XXI/cliente/modal/modal.js"></script>
</body>
</html>
