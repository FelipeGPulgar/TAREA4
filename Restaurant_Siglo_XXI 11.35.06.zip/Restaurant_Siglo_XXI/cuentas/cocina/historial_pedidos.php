<?php
include $_SERVER['DOCUMENT_ROOT'] . '/Restaurant_Siglo_XXI/login/conexion.php';

// Procesar la eliminación si se envía el formulario
if (isset($_POST['eliminar'])) {
    $id_pedido = $_POST['id_pedido'];
    $delete_query = "DELETE FROM pedidos WHERE id_pedido = $id_pedido";
    mysqli_query($conn, $delete_query);
}

// Consulta para obtener los pedidos
$query = "SELECT p.*, u.nombre AS cliente_nombre, pr.nombre AS producto_nombre
          FROM pedidos p
          JOIN usuarios u ON p.id_cliente = u.id_usuario
          JOIN productos pr ON p.id_producto = pr.id_producto
          WHERE p.estado = 'Listo' OR p.estado = 'Entregado'
          ORDER BY p.fecha_hora DESC";

$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Historial de Pedidos</title>
    <link rel="stylesheet" href="historial_pedidos.css">
</head>
<body>
    <h1>Historial de Pedidos</h1>
    <table>
        <thead>
            <tr>
                <th>ID Pedido</th>
                <th>ID Mesa</th>
                <th>Cliente</th>
                <th>Producto</th>
                <th>Total (CLP)</th>
                <th>Estado</th>
                <th>Fecha</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = mysqli_fetch_assoc($result)) { ?>
                <tr>
                    <td><a href="detalles_pedido.php?id_pedido=<?php echo $row['id_pedido']; ?>"><?php echo $row['id_pedido']; ?></a></td>
                    <td><?php echo $row['id_mesa']; ?></td>
                    <td><?php echo $row['cliente_nombre']; ?></td>
                    <td><?php echo $row['producto_nombre']; ?></td>
                    <td><?php echo number_format($row['total'], 0, ',', '.'); ?></td>
                    <td><?php echo $row['estado']; ?></td>
                    <td><?php echo $row['fecha_hora']; ?></td>
                    <td>
                        <!-- Formulario de eliminación -->
                        <form method="POST" onsubmit="return confirm('¿Está seguro de que desea eliminar este pedido?');">
                            <input type="hidden" name="id_pedido" value="<?php echo $row['id_pedido']; ?>">
                            <button type="submit" name="eliminar">Eliminar</button>
                        </form>
                    </td>
                </tr>
            <?php } ?>
        </tbody>
    </table>
    <a href="cocinavista.php" class="btn-volver">Volver</a>
</body>
</html>

<?php
mysqli_close($conn);
?>
