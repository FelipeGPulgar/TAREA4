<?php
// conexión a la base de datos
include $_SERVER['DOCUMENT_ROOT'] . '/Restaurant_Siglo_XXI/login/conexion.php';

if (isset($_GET['id'])) {
    $id_pedido = $_GET['id'];
    // Consultar los detalles del pedido, incluyendo el nombre del producto
    $query = "SELECT p.*, u.nombre AS nombre_cliente, prod.nombre AS nombre_producto 
              FROM pedidos p 
              JOIN usuarios u ON p.id_cliente = u.id_usuario 
              JOIN productos prod ON p.id_producto = prod.id_producto 
              WHERE p.id_pedido = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $id_pedido);
    $stmt->execute();
    $result = $stmt->get_result();
    $pedido = $result->fetch_assoc();

    if (!$pedido) {
        echo "Pedido no encontrado.";
        exit;
    }
} else {
    echo "ID de pedido no proporcionado.";
    exit;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detalles del Pedido</title>
    <link rel="stylesheet" href="detalle_pedido.css">
</head>
<body>
    <div class="container">
        <h1>Detalles del Pedido #<?php echo htmlspecialchars($pedido['id_pedido']); ?></h1>
        <div class="detalle-info">
            <p><strong>Cliente:</strong> <?php echo htmlspecialchars($pedido['nombre_cliente']); ?></p>
            <p><strong>ID Mesa:</strong> <?php echo htmlspecialchars($pedido['id_mesa']); ?></p>
            <p><strong>Nombre del Plato:</strong> <?php echo htmlspecialchars($pedido['nombre_producto']); ?></p>
            <p><strong>Total (CLP):</strong> <?php echo number_format($pedido['total'], 0, ',', '.'); ?></p>
            <p><strong>Estado:</strong> <?php echo htmlspecialchars($pedido['estado']); ?></p>
            <p><strong>Fecha:</strong> <?php echo htmlspecialchars(date('d/m/Y H:i', strtotime($pedido['fecha_hora']))); ?></p>
        </div>
        <a href="cocinavista.php" class="btn-volver">Volver al Tablero</a>
    </div>
</body>
</html>
