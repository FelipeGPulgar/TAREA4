<?php
// conexión a la base de datos
include $_SERVER['DOCUMENT_ROOT'] . '/Restaurant_Siglo_XXI/login/conexion.php';

// obtener los pedidos actuales, incluyendo el nombre del producto
$query = "SELECT p.nombre AS nombre_producto, pe.* 
          FROM pedidos pe
          JOIN productos p ON pe.id_producto = p.id_producto 
          WHERE pe.estado = 'En Preparación'
          ORDER BY pe.fecha_hora ASC"; // Ordena los pedidos por orden de llegada
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tablero de Cocina</title>
    <link rel="stylesheet" href="cocinavista.css">
</head>
<body>
    <h1>Tablero de Cocina</h1>
    <table>
        <thead>
            <tr>
                <th>ID Pedido</th>
                <th>Mesa</th>
                <th>Cliente</th>
                <th>Plato</th>
                <th>Total (CLP)</th>
                <th>Estado</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = mysqli_fetch_assoc($result)) { ?>
                <tr>
                    <td><?php echo $row['id_pedido']; ?></td>
                    <td><?php echo $row['id_mesa']; ?></td>
                    <td><?php echo $row['id_cliente']; ?></td>
                    <td><?php echo $row['nombre_producto']; ?></td>
                    <td><?php echo number_format($row['total'], 0, ',', '.'); ?></td>
                    <td><?php echo $row['estado']; ?></td>
                    <td>
                        <div class="acciones">
                            <form action="actualizar_estado.php" method="POST" style="display:inline;">
                                <input type="hidden" name="id_pedido" value="<?php echo $row['id_pedido']; ?>">
                                <button type="submit" name="accion" value="Listo" class="btn-accion">Marcar como Listo</button>
                            </form>
                            <a href="detalle_pedido.php?id=<?php echo $row['id_pedido']; ?>" class="btn-ver-detalles">Ver Detalles</a>
                        </div>
                    </td>
                </tr>
            <?php } ?>
        </tbody>
    </table>

    <h2>Historial de Pedidos</h2>
    <a href="historial_pedidos.php" class="btn-volver">Ver Historial de Pedidos</a>

    <div style="margin-top: 20px;">
        <a href="/Restaurant_Siglo_XXI/login/login.php" class="btn-volver">Cerrar Session</a>
    </div>
</body>
</html>

<?php
// Cerrar conexión
mysqli_close($conn);
?>
