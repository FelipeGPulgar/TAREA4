<?php
// Conexión a la base de datos
include $_SERVER['DOCUMENT_ROOT'] . '/Restaurant_Siglo_XXI/login/conexion.php';

// Verificar conexión
if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

$error_message = ""; // Variable para almacenar mensajes de error

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $tipo = $_POST['tipo']; // 'Ingreso' o 'Egreso'
    $monto = $_POST['monto'];
    $fecha = date('Y-m-d H:i:s'); // Asegúrate de que la fecha esté en el formato correcto
    $razon = !empty($_POST['razon']) ? $_POST['razon'] : null; // Solo para egresos

    if ($monto > 0) {
        if ($tipo === 'Egreso' && empty($razon)) {
            $error_message = "La razón del egreso es obligatoria.";
        } else {
            // Preparar la consulta de inserción con parámetros
            $stmt = $conn->prepare("INSERT INTO finanzas (tipo, monto, fecha, razon) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("sdss", $tipo, $monto, $fecha, $razon);
            
            if ($stmt->execute()) {
                header("Location: finanzasvista.php?mensaje=Registro agregado con éxito");
                exit();
            } else {
                $error_message = "Error al agregar registro: " . $stmt->error;
            }
            $stmt->close();
        }
    } else {
        $error_message = "El monto debe ser mayor que cero.";
    }
}

// Obtener todos los ingresos y egresos
$query_ingresos = "SELECT * FROM finanzas WHERE tipo='Ingreso'";
$query_egresos = "SELECT * FROM finanzas WHERE tipo='Egreso'";

$result_ingresos = $conn->query($query_ingresos);
$result_egresos = $conn->query($query_egresos);

// Calcular total de ingresos y egresos
$total_ingresos = 0;
$total_egresos = 0;

if ($result_ingresos) {
    while ($row = $result_ingresos->fetch_assoc()) {
        $total_ingresos += $row['monto'];
    }
}

if ($result_egresos) {
    while ($row = $result_egresos->fetch_assoc()) {
        $total_egresos += $row['monto'];
    }
}

$utilidad_diaria = $total_ingresos - $total_egresos;

// Para utilidad mensual
$query_utilidad_mensual = "SELECT SUM(CASE WHEN tipo='Ingreso' THEN monto ELSE 0 END) AS total_ingresos_mensual,
                           SUM(CASE WHEN tipo='Egreso' THEN monto ELSE 0 END) AS total_egresos_mensual
                           FROM finanzas WHERE MONTH(fecha) = MONTH(CURDATE()) AND YEAR(fecha) = YEAR(CURDATE())";

$result_utilidad_mensual = $conn->query($query_utilidad_mensual);
if ($result_utilidad_mensual) {
    $datos_mensuales = $result_utilidad_mensual->fetch_assoc();
    $utilidad_mensual = $datos_mensuales['total_ingresos_mensual'] - $datos_mensuales['total_egresos_mensual'];
}

// Cerrar la conexión
$conn->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Finanzas - Restaurante Siglo XXI</title>
    <link rel="stylesheet" href="finanzasvista.css">
</head>
<body>
    <h1>Control de Finanzas</h1>
    
    <?php if (!empty($error_message)): ?>
        <div class="mensaje" style="color: red;">
            <?php echo htmlspecialchars($error_message); ?>
        </div>
    <?php endif; ?>

    <?php if (isset($_GET['mensaje'])): ?>
        <div class="mensaje" style="color: green;">
            <?php echo htmlspecialchars($_GET['mensaje']); ?>
        </div>
    <?php endif; ?>

    <!-- Formulario para agregar ingresos y egresos -->
    <div class="formulario-finanzas">
        <h2>Agregar Registro</h2>
        <form action="" method="POST">
            <label for="tipo">Tipo:</label>
            <select name="tipo" id="tipo" required>
                <option value="Ingreso">Ingreso</option>
                <option value="Egreso">Egreso</option>
            </select>
            <label for="monto">Monto (CLP):</label>
            <input type="number" name="monto" id="monto" required step="0.01" placeholder="Ej: 15000">
            <label for="razon">Razón (solo para Egresos):</label>
            <input type="text" name="razon" id="razon" placeholder="Ej: Pago de luz">
            <button type="submit">Agregar Registro</button>
        </form>
    </div>

    <!-- Resumen diario y mensual -->
    <div class="resumen-finanzas">
        <h2>Resumen Financiero</h2>
        <p>Total Ingresos: $<?php echo number_format($total_ingresos, 0, '', '.'); ?> CLP</p>
        <p>Total Egresos: $<?php echo number_format($total_egresos, 0, '', '.'); ?> CLP</p>
        <p>Utilidad Diaria: $<?php echo number_format($utilidad_diaria, 0, '', '.'); ?> CLP</p>
        <p>Utilidad Mensual: $<?php echo number_format($utilidad_mensual ?? 0, 0, '', '.'); ?> CLP</p>
    </div>

    <!-- Detalle de ingresos -->
    <div class="detalles-ingresos">
        <h2>Detalles de Ingresos</h2>
        <table>
            <thead>
                <tr>
                    <th>Descripción</th>
                    <th>Monto (CLP)</th>
                    <th>Fecha</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // Mostrar detalles de ingresos
                if ($result_ingresos && $result_ingresos->num_rows > 0) {
                    $result_ingresos->data_seek(0); // Reiniciar puntero
                    while ($row = $result_ingresos->fetch_assoc()) {
                        echo "<tr>
                                <td>{$row['descripcion']}</td>
                                <td>$" . number_format($row['monto'], 0, '', '.') . "</td>
                                <td>{$row['fecha']}</td>
                                <td><a href='eliminar.php?id={$row['id_transaccion']}' onclick='return confirm(\"¿Está seguro de que desea eliminar este ingreso?\");'>Eliminar</a></td>
                              </tr>";
                    }
                } else {
                    echo "<tr><td colspan='4'>No hay ingresos registrados.</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>

    <!-- Detalle de egresos -->
    <div class="detalles-egresos">
        <h2>Detalles de Egresos</h2>
        <table>
            <thead>
                <tr>
                    <th>Razón</th>
                    <th>Monto (CLP)</th>
                    <th>Fecha</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // Mostrar detalles de egresos
                if ($result_egresos && $result_egresos->num_rows > 0) {
                    $result_egresos->data_seek(0); // Reiniciar puntero
                    while ($row = $result_egresos->fetch_assoc()) {
                        echo "<tr>
                                <td>{$row['razon']}</td>
                                <td>$" . number_format($row['monto'], 0, '', '.') . "</td>
                                <td>{$row['fecha']}</td>
                                <td><a href='eliminar.php?id={$row['id_transaccion']}' onclick='return confirm(\"¿Está seguro de que desea eliminar este egreso?\");'>Eliminar</a></td>
                              </tr>";
                    }
                } else {
                    echo "<tr><td colspan='4'>No hay egresos registrados.</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
    <div>
        <a href="/Restaurant_Siglo_XXI/login/login.php" class="btn-volver">Cerrar Session</a>
    </div>
</body>
</html>
