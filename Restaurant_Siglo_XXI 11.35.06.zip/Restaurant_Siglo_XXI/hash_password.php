<?php
include $_SERVER['DOCUMENT_ROOT'] . '/Restaurant_Siglo_XXI/login/conexion.php';

$usuarios = [
    ['id' => 1, 'password' => 'password'],
    ['id' => 2, 'password' => 'password'],
    ['id' => 3, 'password' => 'password'],
    ['id' => 4, 'password' => 'password'],
    ['id' => 5, 'password' => 'password']
];

foreach ($usuarios as $usuario) {
    $id = $usuario['id'];
    $hashed_password = password_hash($usuario['password'], PASSWORD_DEFAULT);
    $query = "UPDATE usuarios SET password = ? WHERE id_usuario = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("si", $hashed_password, $id);
    $stmt->execute();
}

